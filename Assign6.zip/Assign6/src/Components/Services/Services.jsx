import React from "react";
import "./Services.css";

export default function Services() {
  return <div className="services-container">
    <div className="service">
        <i className="far fa-lightbulb"></i>
        <h2>Creative</h2>
    </div>
    <div className="service">
        <i className="fas fa-cut"></i>
        <h2>Problem Solving</h2>
    </div>
    <div className="service">
        <i className="fas fa-tachometer-alt"></i>
        <h2>Fast</h2>
    </div>
    <div className="service">
        <i className="fas fa-rocket"></i>
        <h2>Dynamic</h2>
    </div>
  </div>;
}
