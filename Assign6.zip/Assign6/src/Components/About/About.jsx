import React from "react";
import ProgressBar from "../ProgressBar";
import "./About.css";

export default function About() {
  let skills = [
    {
      skill: "HTML",
      percent: "60"
    },
    {
      skill: "CSS",
      percent: "70"
    },
    {
      skill: "JS",
      percent: "80"
    },
    {
      skill: "SASS",
      percent: "40"
    },
    {
      skill: "REACT JS",
      percent: "80"
    },
    {
      skill: "NODE JS",
      percent: "60"
    },
    {
      skill: "MONGO DB",
      percent: "70"
    }
  ];
  return (
    <div className="about-container">
      <h2>About me</h2>
      <div className="progress-bar-wrapper">
        {
            skills.map(el=><ProgressBar  progress={el.percent} skill={el.skill} />)
        }
      </div>
    </div>
  );
}
