import React from "react";
import About from "./About/About";
import Contact from "./Contact/Contact";
import Footer from "./Footer/Footer";
import Header from "./Header/Header";
import MyProject from "./MyProject/MyProject";
import Services from "./Services/Services";
import SubHeader from "./SubHeader/SubHeader";

export default function Home() {
  return (
    <div>
      <Header />
      <SubHeader />
      <About />
      <Services />
      <MyProject />
      <Contact />
      <Footer />
    </div>
  );
}
