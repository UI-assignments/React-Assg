import React from 'react'
import './Contact.css'

export default function Contact() {
  return (
    <div className='contact-container'>
        <h1>Contact me</h1>
        <form class="contact-form">
          <input type="text" placeholder="Name" />
          <input type="email" placeholder="Email" />
          <textarea placeholder="Message"></textarea>
          <input type="submit" value="Submit" class="contact-form-btn" />
        </form>
    </div>
  )
}
