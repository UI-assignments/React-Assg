import React from "react";
import "./SubHeader.css";

export default function SubHeader() {
  return (
    <nav>
      <a href="#">Home</a>
      <a href="/">About</a>
      <a href="/">Portfolio</a>
      <a href="/">Contacts</a>
    </nav>
  );
}
