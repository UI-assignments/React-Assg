import React from "react";
import './MyProject.css';
import Project from "../Project/Project";
import projectimg1 from "../../images/project-1.jpg";
import projectimg2 from "../../images/project-2.jpg";
import projectimg3 from "../../images/project-3.jpg";
import projectimg4 from "../../images/project-4.jpg";
import projectimg5 from "../../images/project-5.jpg";
import projectimg6 from "../../images/project-6.jpg";
import projectimg7 from "../../images/project-7.jpg";
import projectimg8 from "../../images/project-8.jpg";
import projectimg9 from "../../images/project-9.jpg";

export default function MyProject() {
  let projectarray = [
    {
      projectName: "architect Website",
      img: projectimg1,
      technologies: "HTML,CSS,JS"
    },
    {
      projectName: "budget app",
      img: projectimg2,
      technologies: "React JS"
    },
    {
      projectName: "wine house",
      img: projectimg3,
      technologies: "HTML/CSS/JS"
    },
    {
      projectName: "task manager",
      img: projectimg4,
      technologies: "React JS"
    },
    {
      projectName: "The Road",
      img: projectimg5,
      technologies: "HTML /CSS/JS"
    },
    {
      projectName: "Food recipe app",
      img: projectimg6,
      technologies: "React JS"
    },
    {
      projectName: "slideshow",
      img: projectimg7,
      technologies: "HTML/CSS/JS"
    },
    {
      projectName: "hamburger menu",
      img: projectimg8,
      technologies: "HTML/CSS/JS"
    },
    {
      projectName: "Css grid menu",
      img: projectimg9,
      technologies: "HTML/Css/JS"
    },
  ];
  return (
    <div className="myproject-container">
      <h1>My Projects</h1>
      <div className="projects">
        {projectarray.map((el) => (
          <Project img={el.img} name={el.projectName} tech={el.technologies} />
        ))}
      </div>
    </div>
  );
}
