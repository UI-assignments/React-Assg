import React from "react";
import './Project.css';

export default function Project({img, name, tech}) {
  return (
    <div className="project">
      <div className="project-text">
        <h2 className="project-name">{name}</h2>
        <h4 className="project-tech">{tech}</h4>
      </div>
      <img src={`${img}`} alt="" />
      <a
        href="https://www.youtube.com/watch?v=3J-EFMzz94g"
        className="project-link"
        target="_blank"
      >
        Go to Video
      </a>
    </div>
  );
}
