import React from "react";

export default function MainContent() {
  return (
    <div
      style={{
        border: "4px solid grey",


        width: "60%",
        height: "300px",

        color: "lightgreen",
        display: "flex",

        justifyContent: "center",

        alignItems: "center"
      }}
    >
      <h1>MainContent</h1>
      
    </div>
  );
}
