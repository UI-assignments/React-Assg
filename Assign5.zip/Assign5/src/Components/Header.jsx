import React from "react";

export default function Header() {
  return (
    <div
      style={{ border: "4px solid grey", color: "lightgreen", margin:"4px" }}
    >
      <h1>Header</h1>
    </div>
  );
}
