import React from "react";

export default function Footer() {
  return (
    <div
      style={{ border: "4px solid grey", 
      margin: "4px", 
      color: "lightgreen" }}
    >
      <h1>Footer</h1>
    </div>
  );
}
